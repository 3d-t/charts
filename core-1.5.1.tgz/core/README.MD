# Spacetime helm chart

This chart enables installation of all required core modules. After making changes to the dependencies run:

```
helm dependency update .
```
